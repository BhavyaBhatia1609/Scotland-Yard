package uk.ac.bris.cs.scotlandyard.model;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;

import javax.annotation.Nonnull;

import uk.ac.bris.cs.scotlandyard.model.ScotlandYard.Factory;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

/**
 * cw-model
 * Stage 2: Complete this class
 */
public final class MyModelFactory implements Factory<Model> {

	private final class MyModel implements Model{
		Board.GameState gState;
		List<Observer> observers;

		private MyModel(Board.GameState gState){
			this.gState = gState;
			observers = new ArrayList<>();
		}

		public Board getCurrentBoard() { return gState; }

		@Override
		public void registerObserver(Observer observer) {
			if (observer == null) throw new NullPointerException();
			if(!observers.contains(observer)){
				observers.add(observer);
			} else throw new IllegalArgumentException();
		}

		@Override
		public void unregisterObserver(Observer observer) {
			if (observer == null) throw new NullPointerException();
			if(observers.contains(observer)){
				observers.remove(observer);
			} else throw new IllegalArgumentException();
		}

		@Override
		public ImmutableSet<Observer> getObservers() {
			return ImmutableSet.copyOf(new HashSet(observers));
		}

		@Override
		public void chooseMove(Move move) {
			gState = gState.advance(move);
			if (gState.getWinner().isEmpty()){
				for(Observer o : observers){
					o.onModelChanged(gState, Observer.Event.MOVE_MADE);
				}
			} else {
				for(Observer o : observers){
					o.onModelChanged(gState, Observer.Event.GAME_OVER);
				}
			}
		}


	}

	@Nonnull @Override public Model build(GameSetup setup,
										  Player mrX,
										  ImmutableList<Player> detectives) {
		// TODO
		MyGameStateFactory factory = new MyGameStateFactory();
		Board.GameState gState = factory.build(setup, mrX, detectives);
		return new MyModel(gState);
	}
}
