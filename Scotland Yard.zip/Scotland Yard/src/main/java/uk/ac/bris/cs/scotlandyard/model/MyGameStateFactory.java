package uk.ac.bris.cs.scotlandyard.model;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import uk.ac.bris.cs.scotlandyard.model.Board.GameState;
import uk.ac.bris.cs.scotlandyard.model.ScotlandYard.Factory;

import javax.annotation.Nonnull;
import java.util.*;
import java.util.stream.Collectors;

/**
 * cw-model
 * Stage 1: Complete this class
 */
public final class MyGameStateFactory implements Factory<GameState> {

	private final class MyGameState implements GameState{
		private GameSetup setup;
		private ImmutableSet<Piece> remaining;
		private ImmutableList<LogEntry> log;
		private Player mrX;
		private List<Player> detectives;
		private ImmutableSet<Piece> winner;
		private ImmutableSet<Move> moves;


		private MyGameState(final GameSetup setup, final ImmutableSet<Piece> remaining,
							final ImmutableList<LogEntry> log, final Player mrX, final List<Player> detectives){
			if (setup.moves.isEmpty()) throw new IllegalArgumentException();
			if (setup.graph.nodes().isEmpty()) throw new IllegalArgumentException();
			this.setup = setup;
			this.remaining = remaining;
			this.log = log;
			if (mrX == null) throw new NullPointerException();
			this.mrX = mrX;
			if (detectives == null) throw new NullPointerException();
			for (Player x : detectives) {
				if (x == null) throw new IllegalArgumentException();
				if (x.has(ScotlandYard.Ticket.DOUBLE) || x.has(ScotlandYard.Ticket.SECRET)){
					throw new IllegalArgumentException();
				}
			}
			for (int i = 0; i < detectives.size(); i++){
				for (int j = i+1; j < detectives.size(); j++){
					Player d1 = detectives.get(i);
					Player d2 = detectives.get(j);
					if (d1.location() == d2.location() || d1.equals(d2)) throw new IllegalArgumentException();
				}
			}
			this.detectives = detectives;
			this.moves = getAvailableMoves();
			winner = getWinner();
		}

		@Override
		public ImmutableSet<Piece> getPlayers(){
			HashSet<Piece> res = new HashSet<>();
			for (Player p : detectives) {
				res.add(p.piece());
			}
			res.add(Piece.MrX.MRX);
			return ImmutableSet.copyOf(res);
		}

		@Override
		public Optional<TicketBoard> getPlayerTickets(Piece piece){
			for (Player p : detectives){
				if (p.piece() == piece){
					return Optional.ofNullable(p.tickets())
							.map(tickets -> ticket -> p.tickets().getOrDefault(ticket, 0));
				}
			}
			if (piece == Piece.MrX.MRX) return Optional.ofNullable(mrX.tickets())
					.map(tickets -> ticket -> mrX.tickets().getOrDefault(ticket, 0));
			return Optional.empty();
		}

		@Override
		public GameSetup getSetup() { return setup; }

		@Override
		public ImmutableList<LogEntry> getMrXTravelLog() { return log; }

		@Override
		public Optional<Integer> getDetectiveLocation(Piece.Detective d) {
			for (Player p : detectives){
				if (p.piece() == d){
					return Optional.of(p.location());
				}
			}
			return Optional.empty();
		}

		@Override
		public ImmutableSet<Move> getAvailableMoves(){
			if(winner != null && !winner.isEmpty()) return ImmutableSet.of();
			HashSet<Move> res = new HashSet<>();
			for(Piece piece: remaining) {
				int i = getPlayerFromPiece(piece);
				Player p;
				if (i > -1) p = detectives.get(i);
				else if (i == -1) p = this.mrX;
				else throw new IllegalArgumentException();
				res.addAll(getSingleMoves(setup, detectives, p, p.location()));
				if (p.has(ScotlandYard.Ticket.DOUBLE) && setup.moves.size() > log.size() + 1){
					res.addAll(getDoubleMoves(setup, detectives, p, p.location()));
				}
			}
			return ImmutableSet.copyOf(res);
		}

		private int getPlayerFromPiece(Piece p){
			if (p == Piece.MrX.MRX) return -1;
			for (int i = 0; i < detectives.size(); i++){
				if (detectives.get(i).piece() == p) return i;
			}
			return -2;
		}

		private List<Player> setGivenDetective(Player p){
			ArrayList<Player> res = new ArrayList<>();
			for (Player pl : detectives){
				if (pl.piece() != p.piece()) res.add(pl);
			}
			res.add(p);
			return res;
		}

		@Override
		public GameState advance(Move move){
			if(!this.moves.contains(move)) throw new IllegalArgumentException();
			boolean x = false;
			if (remaining.contains(Piece.MrX.MRX)) x = true;
			int i = getPlayerFromPiece(move.commencedBy());
			Player p;
			if (i > -1) p = detectives.get(i);
			else if (i == -1) p = mrX;
			else throw new IllegalArgumentException();

			Move.FunctionalVisitor<List<Move.SingleMove>> visitor = new Move.FunctionalVisitor<>
					(MyGameState::singleMoveVisit, MyGameState::doubleMoveVisit);

			List<Move.SingleMove> singleMoves = move.accept(visitor);
			if (singleMoves.size() == 2){
				p = p.use(ScotlandYard.Ticket.DOUBLE);
			}
			for (Move.SingleMove m : singleMoves){
				p = p.use(m.ticket);
				p = p.at(m.destination);
				if (move.commencedBy().isMrX()) {
					ArrayList<LogEntry> newLog = new ArrayList<>();
					Iterator<LogEntry> it = log.listIterator();
					while(it.hasNext()){
						newLog.add(it.next());
					}
					if (setup.moves.get(log.size())){
						newLog.add(LogEntry.reveal(m.ticket, m.destination));
					} else {
						newLog.add(LogEntry.hidden(m.ticket));
					}
					log = ImmutableList.copyOf(newLog);
					this.mrX = p;
				} else {
					detectives = setGivenDetective(p);
					mrX = mrX.give(m.ticket);
				}
				HashSet<Piece> newRem = new HashSet<>();
				Iterator<Piece> it = remaining.asList().listIterator();
				while(it.hasNext()){
					Piece next = it.next();
					if(next != m.commencedBy()){
						newRem.add(next);
					}
				}
				remaining = ImmutableSet.copyOf(newRem);
			}

			if(remaining.isEmpty()){
				if (x) {
					HashSet<Piece> res = new HashSet<>();
					detectives.stream().map(Player::piece).forEach(res::add);
					remaining = ImmutableSet.copyOf(res);
				} else {
					remaining = ImmutableSet.of(Piece.MrX.MRX);
				}
			}

			return new MyGameState(setup, remaining, log, mrX, detectives);


		}

		private static Set<Move.SingleMove> getSingleMoves(GameSetup setup, List<Player> detectives, Player p, int s){
			HashSet<Move.SingleMove> res = new HashSet<>();

			for(int destination: setup.graph.adjacentNodes(s)) {
				boolean occupied = false;
				for (Player player : detectives){
					if (player.location() == destination){
						occupied = true;
						break;
					}
				}
				if(!occupied){
					for (ScotlandYard.Transport t: setup.graph.edgeValueOrDefault(s, destination, ImmutableSet.of())){
						if (p.has(t.requiredTicket())){
							res.add(new Move.SingleMove(p.piece(), s, t.requiredTicket(), destination));
						}
						if (t.requiredTicket() != ScotlandYard.Ticket.SECRET && p.has(ScotlandYard.Ticket.SECRET)){
							res.add(new Move.SingleMove(p.piece(), s, ScotlandYard.Ticket.SECRET, destination));
						}
					}
				}
			}
			return res;
		}

		private static Set<Move.DoubleMove> getDoubleMoves(GameSetup setup, List<Player> detectives, Player p, int s){
			Set<Move.SingleMove> singles = getSingleMoves(setup, detectives, p, s);
			HashSet<Move.DoubleMove> res = new HashSet<>();
			for (Move.SingleMove m : singles) {
				Set<Move.SingleMove> cont = getSingleMoves(setup, detectives, p, m.destination);
				for(Move.SingleMove m2 : cont) {
					if (m.ticket == m2.ticket){
						if (p.hasAtLeast(m.ticket, 2)){
							res.add(new Move.DoubleMove(p.piece(), s, m.ticket, m.destination,
									m2.ticket, m2.destination));
						}
					} else {
						res.add(new Move.DoubleMove(p.piece(), s, m.ticket, m.destination,
								m2.ticket, m2.destination));
					}
				}
			}
			return res;
		}

		private static List<Move.SingleMove> singleMoveVisit(Move.SingleMove m){
			return List.of(m);
		}

		private static List<Move.SingleMove> doubleMoveVisit(Move.DoubleMove m){
			Move.SingleMove m1 = new Move.SingleMove(m.commencedBy(), m.source(), m.ticket1, m.destination1);
			Move.SingleMove m2 = new Move.SingleMove(m.commencedBy(), m.destination1, m.ticket2, m.destination2);
			return List.of(m1, m2);
		}
		public ImmutableSet<Piece> getWinner(){
			HashSet<Piece> det = new HashSet<>();
			for (Player p : detectives){
				det.add(p.piece());
			}
			ImmutableSet<Piece> d = ImmutableSet.copyOf(det);
			ImmutableSet<Piece> x = ImmutableSet.of(Piece.MrX.MRX);
			boolean dCanMove = false;
			for (Player p : detectives) {
				if (p.location() == mrX.location()){
					this.moves = ImmutableSet.of();
					return d;
				}
				if (!getSingleMoves(setup, detectives, p, p.location()).isEmpty()){
					dCanMove = true;
				}
			}
			if(!dCanMove) return x;
			if (moves.isEmpty()) {
				if (remaining.contains(Piece.MrX.MRX)) return d;
				else return x;
			}
			if (remaining.contains(Piece.MrX.MRX) && log.size() == setup.moves.size()) {
				moves = ImmutableSet.of();
				return x;
			}

			return ImmutableSet.of();
		}
	}

	@Nonnull @Override public GameState build(
			GameSetup setup,
			Player mrX,
			ImmutableList<Player> detectives) {

		return new MyGameState(setup, ImmutableSet.of(Piece.MrX.MRX), ImmutableList.of(), mrX, detectives);

	}

}
